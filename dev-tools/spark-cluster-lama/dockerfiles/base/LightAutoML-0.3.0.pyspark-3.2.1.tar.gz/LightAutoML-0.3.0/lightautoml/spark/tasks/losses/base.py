from lightautoml.tasks.losses.base import Loss


class SparkLoss(Loss):
    def __init__(self):
        pass
